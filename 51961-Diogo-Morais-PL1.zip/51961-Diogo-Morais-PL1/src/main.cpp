#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <vector>
#include <string>
#include <map>
#include <fstream>
#include <algorithm>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

GLFWwindow* window;

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
using namespace glm;

#include <common/shader.hpp>

// Leitura de imagens (texturas). Ficheiro: common/stb_image.h
#define STB_IMAGE_IMPLEMENTATION
#include <common/stb_image.h>

// ------------------------------------------------------------
// CAMINHOS E CONFIGURAÇÕES DA PISTA
// ------------------------------------------------------------
const char* AIRCRAFT_OBJ = "models/aircraft.obj";
const char* RUNWAY_OBJ   = "models/runway.obj";
const char* TERRAIN_OBJ  = "models/terrain.obj";

// O programa assume nariz a apontar para +X. Se nao estiver, mudar: 90, -90, 180.
const float AIRCRAFT_YAW_FIX = 90.0f;

// Tamanho (comprimento) do aviao, da pista e do terreno em unidades do mundo
const float AIRCRAFT_SIZE  = 20.0f;
const float RUNWAY_LENGTH  = 900.0f;
const float TERRAIN_SIZE   = 3000.0f;

// AJUSTES DA PISTA (Desvio lateral e altura para encaixar no terreno)
const float RUNWAY_OFFSET_Z = 300.0f;   
const float RUNWAY_OFFSET_Y = -126.5f;    

// ------------------------------------------------------------
// VARIAVEIS GLOBAIS
// ------------------------------------------------------------
GLuint VertexArrayID;
GLuint programID;
GLuint MatrixID, ModelID, NormalID, LightPosID, ViewPosID;
GLuint UseTexID, ColorID, TexID;

GLint WindowWidth  = 1024;
GLint WindowHeight = 768;

struct SubMesh {
    GLuint vbo = 0;
    GLsizei count = 0;
    glm::vec3 kd = glm::vec3(0.7f);
    GLuint tex = 0;
};

struct Model {
    std::vector<SubMesh> parts;
    glm::vec3 mn = glm::vec3(0.0f);
    glm::vec3 mx = glm::vec3(0.0f);
};

struct Material {
    glm::vec3 kd = glm::vec3(0.7f);
    std::string tex;
};

Model aircraftModel, runwayModel, terrainModel;

// ------------------------------------------------------------
// CAMARA
// ------------------------------------------------------------
float camYaw   = 135.0f;
float camPitch = 20.0f;
float camDist  = 35.0f;
glm::vec3 camTarget = glm::vec3(-450.0f, 0.0f, RUNWAY_OFFSET_Z);
bool chaseCamera = true;

bool dragging = false;
double lastX = 0, lastY = 0;

// ------------------------------------------------------------
// SIMULACAO DA DESCOLAGEM
// ------------------------------------------------------------
enum FlightState { PARKED, ROLLING, ROTATING, CLIMBING, FINISHED };

const float START_X      = -420.0f;
const float ACCELERATION = 4.0f;    
const float ROTATE_SPEED = 55.0f;   
const float MAX_PITCH    = 14.0f;   
const float PITCH_RATE   = 4.0f;    
const float MAX_SPEED    = 90.0f;

FlightState state = PARKED;
glm::vec3 planePos = glm::vec3(START_X, RUNWAY_OFFSET_Y, RUNWAY_OFFSET_Z);
float planeSpeed = 0.0f;
float planePitch = 0.0f;
bool running = false;

const char* stateName(FlightState s)
{
    switch (s) {
        case PARKED:   return "PARADO";
        case ROLLING:  return "ARRANQUE";
        case ROTATING: return "ROTACAO";
        case CLIMBING: return "SUBIDA";
        default:       return "FIM";
    }
}

void resetSimulation()
{
    state = PARKED;
    running = false;
    planePos = glm::vec3(START_X, RUNWAY_OFFSET_Y, RUNWAY_OFFSET_Z);
    planeSpeed = 0.0f;
    planePitch = 0.0f;
}

// função de simulação
void updateSimulation(float dt)
{
    if (!running) return;

    switch (state) {
    case PARKED:
        state = ROLLING;
        break;

    case ROLLING:
        planeSpeed += ACCELERATION * dt;
        planePos.x += planeSpeed * dt;
        if (planeSpeed >= ROTATE_SPEED) state = ROTATING;
        break;

    case ROTATING:
        planeSpeed += ACCELERATION * dt;
        planePos.x += planeSpeed * dt;
        planePitch = std::min(planePitch + PITCH_RATE * dt, MAX_PITCH);
        if (planePitch >= 6.0f) state = CLIMBING;
        break;

    case CLIMBING:
        planeSpeed = std::min(planeSpeed + 0.5f * ACCELERATION * dt, MAX_SPEED);
        planePitch = std::min(planePitch + PITCH_RATE * dt, MAX_PITCH);
        planePos.x += planeSpeed * cosf(glm::radians(planePitch)) * dt;
        planePos.y += planeSpeed * sinf(glm::radians(planePitch)) * dt;
        if (planePos.x > 1400.0f) { state = FINISHED; running = false; }
        break;

    default:
        break;
    }
}

// ------------------------------------------------------------
// FUNCOES AUXILIARES
// ------------------------------------------------------------
static std::string trim(const std::string& s)
{
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static std::string dirOf(const std::string& path)
{
    size_t p = path.find_last_of("/\\");
    return (p == std::string::npos) ? "" : path.substr(0, p + 1);
}

static std::string baseName(const std::string& path)
{
    size_t p = path.find_last_of("/\\");
    return (p == std::string::npos) ? path : path.substr(p + 1);
}

void pushVertex(std::vector<float>& d, glm::vec3 p, glm::vec3 n, glm::vec2 uv)
{
    d.push_back(p.x);  d.push_back(p.y);  d.push_back(p.z);
    d.push_back(n.x);  d.push_back(n.y);  d.push_back(n.z);
    d.push_back(uv.x); d.push_back(uv.y);
}

SubMesh uploadPart(const std::vector<float>& d, glm::vec3 kd, GLuint tex)
{
    SubMesh m;
    m.count = (GLsizei)(d.size() / 8);
    m.kd = kd;
    m.tex = tex;
    glGenBuffers(1, &m.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, d.size() * sizeof(float), d.data(), GL_STATIC_DRAW);
    return m;
}

// ------------------------------------------------------------
// TEXTURAS
// ------------------------------------------------------------
std::map<std::string, GLuint> textureCache;

GLuint loadTexture(const std::string& fullPath)
{
    std::map<std::string, GLuint>::iterator it = textureCache.find(fullPath);
    if (it != textureCache.end()) return it->second;

    stbi_set_flip_vertically_on_load(1);
    int w, h, n;
    unsigned char* data = stbi_load(fullPath.c_str(), &w, &h, &n, 4);
    if (data == NULL) {
        textureCache[fullPath] = 0;
        return 0;
    }

    GLuint t;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(data);

    textureCache[fullPath] = t;
    return t;
}

GLuint resolveTexture(const std::string& dir, std::string name)
{
    for (size_t i = 0; i < name.size(); i++)
        if (name[i] == '\\') name[i] = '/';

    GLuint t = loadTexture(dir + name);
    if (t == 0) t = loadTexture(dir + baseName(name));
    return t;
}

GLuint loadTextureAnyExt(const std::string& base)
{
    const char* exts[] = { ".png", ".jpg", ".jpeg", ".bmp", ".tga" };
    for (int i = 0; i < 5; i++) {
        GLuint t = loadTexture(base + exts[i]);
        if (t != 0) return t;
    }
    return 0;
}

// ------------------------------------------------------------
// LEITOR DE .MTL 
// ------------------------------------------------------------
std::map<std::string, Material> loadMTL(const std::string& path)
{
    std::map<std::string, Material> mats;
    std::ifstream f(path.c_str());
    if (!f.is_open()) return mats;

    std::string line, cur;
    while (std::getline(f, line)) {
        line = trim(line);
        if (line.compare(0, 7, "newmtl ") == 0) {
            cur = trim(line.substr(7));
            mats[cur] = Material();
        } else if (!cur.empty() && line.compare(0, 3, "Kd ") == 0) {
            float r, g, b;
            if (sscanf(line.c_str() + 3, "%f %f %f", &r, &g, &b) == 3)
                mats[cur].kd = glm::vec3(r, g, b);
        } else if (!cur.empty() && line.compare(0, 7, "map_Kd ") == 0) {
            mats[cur].tex = trim(line.substr(7));
        }
    }
    return mats;
}

// ------------------------------------------------------------
// LEITOR DE .OBJ 
// ------------------------------------------------------------
struct Tri {
    glm::vec3 p[3];
    glm::vec3 n[3];
    glm::vec2 uv[3];
    int mat;
};

static void parseFaceToken(const char* tok, int& vi, int& ti, int& ni)
{
    vi = ti = ni = 0;
    if (sscanf(tok, "%d/%d/%d", &vi, &ti, &ni) == 3) return;
    vi = ti = ni = 0;
    if (sscanf(tok, "%d//%d", &vi, &ni) == 2) return;
    vi = ti = ni = 0;
    if (sscanf(tok, "%d/%d", &vi, &ti) == 2) return;
    vi = ti = ni = 0;
    sscanf(tok, "%d", &vi);
}

static int fixIndex(int idx, int size)
{
    if (idx > 0) return idx - 1;
    if (idx < 0) return size + idx;
    return -1;
}

bool loadModel(const char* pathC, float targetLen, float yawDeg,
               bool autoAlignX, bool alignTop, Model& model,
               const char* defaultTexBase = "")
{
    std::string path = pathC;
    std::string dir = dirOf(path);

    FILE* file = fopen(pathC, "r");
    if (file == NULL) return false;

    std::vector<glm::vec3> V, VN;
    std::vector<glm::vec2> VT;
    std::vector<Tri> tris;
    std::map<std::string, Material> mtls;
    std::vector<std::string> matNames;
    matNames.push_back("");
    int curMat = 0;

    static char line[8192];
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == 'v' && line[1] == ' ') {
            glm::vec3 v(0.0f);
            sscanf(line + 2, "%f %f %f", &v.x, &v.y, &v.z);
            V.push_back(v);
        }
        else if (line[0] == 'v' && line[1] == 't') {
            glm::vec2 t(0.0f);
            sscanf(line + 3, "%f %f", &t.x, &t.y);
            VT.push_back(t);
        }
        else if (line[0] == 'v' && line[1] == 'n') {
            glm::vec3 v(0.0f);
            sscanf(line + 3, "%f %f %f", &v.x, &v.y, &v.z);
            VN.push_back(v);
        }
        else if (line[0] == 'f' && line[1] == ' ') {
            std::vector<int> vi, ti, ni;
            char* tok = strtok(line + 2, " \t\r\n");
            while (tok != NULL) {
                int a, b, c;
                parseFaceToken(tok, a, b, c);
                vi.push_back(fixIndex(a, (int)V.size()));
                ti.push_back(b != 0 ? fixIndex(b, (int)VT.size()) : -1);
                ni.push_back(c != 0 ? fixIndex(c, (int)VN.size()) : -1);
                tok = strtok(NULL, " \t\r\n");
            }

            for (size_t k = 1; k + 1 < vi.size(); k++) {
                int idx[3] = { 0, (int)k, (int)k + 1 };
                Tri t;
                t.mat = curMat;
                bool ok = true, allN = true;

                for (int j = 0; j < 3; j++) {
                    int a = vi[idx[j]];
                    if (a < 0 || a >= (int)V.size()) { ok = false; break; }
                    t.p[j] = V[a];

                    int b = ti[idx[j]];
                    t.uv[j] = (b >= 0 && b < (int)VT.size()) ? VT[b] : glm::vec2(0.0f);

                    int c = ni[idx[j]];
                    if (c >= 0 && c < (int)VN.size()) t.n[j] = VN[c];
                    else allN = false;
                }
                if (!ok) continue;

                if (!allN) {
                    glm::vec3 fn = glm::cross(t.p[1] - t.p[0], t.p[2] - t.p[0]);
                    float l = glm::length(fn);
                    fn = (l > 1e-12f) ? fn / l : glm::vec3(0, 1, 0);
                    t.n[0] = t.n[1] = t.n[2] = fn;
                }
                tris.push_back(t);
            }
        }
        else if (strncmp(line, "mtllib ", 7) == 0) {
            std::string m = trim(line + 7);
            std::map<std::string, Material> got = loadMTL(dir + m);
            mtls.insert(got.begin(), got.end());
        }
        else if (strncmp(line, "usemtl ", 7) == 0) {
            std::string name = trim(line + 7);
            curMat = -1;
            for (size_t i = 0; i < matNames.size(); i++)
                if (matNames[i] == name) { curMat = (int)i; break; }
            if (curMat < 0) {
                matNames.push_back(name);
                curMat = (int)matNames.size() - 1;
            }
        }
    }
    fclose(file);

    if (tris.empty()) return false;

    glm::vec3 mn(1e30f), mx(-1e30f);
    for (size_t i = 0; i < tris.size(); i++)
        for (int j = 0; j < 3; j++) {
            mn = glm::min(mn, tris[i].p[j]);
            mx = glm::max(mx, tris[i].p[j]);
        }

    float yaw = yawDeg;
    if (autoAlignX && (mx.z - mn.z) > (mx.x - mn.x)) yaw += 90.0f;

    float c = cosf(glm::radians(yaw));
    float s = sinf(glm::radians(yaw));
    for (size_t i = 0; i < tris.size(); i++)
        for (int j = 0; j < 3; j++) {
            glm::vec3& p = tris[i].p[j];
            glm::vec3& n = tris[i].n[j];
            float px =  p.x * c + p.z * s;
            float pz = -p.x * s + p.z * c;
            p.x = px; p.z = pz;
            float nx =  n.x * c + n.z * s;
            float nz = -n.x * s + n.z * c;
            n.x = nx; n.z = nz;
        }

    mn = glm::vec3(1e30f);
    mx = glm::vec3(-1e30f);
    for (size_t i = 0; i < tris.size(); i++)
        for (int j = 0; j < 3; j++) {
            mn = glm::min(mn, tris[i].p[j]);
            mx = glm::max(mx, tris[i].p[j]);
        }

    float longest = std::max(mx.x - mn.x, mx.z - mn.z);
    if (longest < 1e-9f) longest = std::max(mx.y - mn.y, 1e-9f);
    float scale = targetLen / longest;
    float cx = 0.5f * (mn.x + mx.x);
    float cz = 0.5f * (mn.z + mx.z);
    float yRef = alignTop ? mx.y : mn.y;

    std::vector< std::vector<float> > buckets(matNames.size());
    model.mn = glm::vec3(1e30f);
    model.mx = glm::vec3(-1e30f);

    for (size_t i = 0; i < tris.size(); i++) {
        for (int j = 0; j < 3; j++) {
            glm::vec3 p((tris[i].p[j].x - cx) * scale,
                        (tris[i].p[j].y - yRef) * scale,
                        (tris[i].p[j].z - cz) * scale);
            glm::vec3 n = glm::normalize(tris[i].n[j]);
            pushVertex(buckets[tris[i].mat], p, n, tris[i].uv[j]);
            model.mn = glm::min(model.mn, p);
            model.mx = glm::max(model.mx, p);
        }
    }

    for (size_t m = 0; m < buckets.size(); m++) {
        if (buckets[m].empty()) continue;

        Material mat;
        std::map<std::string, Material>::iterator it = mtls.find(matNames[m]);
        if (it != mtls.end()) mat = it->second;

        GLuint tex = 0;
        if (!mat.tex.empty()) {
            tex = resolveTexture(dir, mat.tex);
        }

        if (tex == 0 && defaultTexBase[0] != '\0') {
            tex = loadTextureAnyExt(defaultTexBase);
        }

        glm::vec3 kd = mat.kd;
        if (glm::length(kd) < 0.05f) kd = glm::vec3(0.6f);
        if (!mat.tex.empty() && tex == 0) kd = glm::vec3(0.45f);

        model.parts.push_back(uploadPart(buckets[m], kd, tex));
    }

    return true;
}

// ------------------------------------------------------------
// TRANSFERENCIA DOS DADOS PARA A GPU
// ------------------------------------------------------------
void transferDataToGPUMemory(void)
{
    glGenVertexArrays(1, &VertexArrayID);
    glBindVertexArray(VertexArrayID);

    programID = LoadShaders(
        "PhongVertexShader.vertexshader",
        "PhongFragmentShader.fragmentshader"
    );

    MatrixID   = glGetUniformLocation(programID, "MVP");
    ModelID    = glGetUniformLocation(programID, "M");
    NormalID   = glGetUniformLocation(programID, "normalMatrix");
    LightPosID = glGetUniformLocation(programID, "lightPos");
    ViewPosID  = glGetUniformLocation(programID, "viewPos");
    UseTexID   = glGetUniformLocation(programID, "useTex");
    ColorID    = glGetUniformLocation(programID, "baseColor");
    TexID      = glGetUniformLocation(programID, "tex");

    if (!loadModel(AIRCRAFT_OBJ, AIRCRAFT_SIZE, AIRCRAFT_YAW_FIX, false, false, aircraftModel, "models/aircraft")) {
        printf("Erro: nao consegui carregar o aviao\n");
        exit(-1);
    }

    if (!loadModel(RUNWAY_OBJ, RUNWAY_LENGTH, 0.0f, true, true, runwayModel, "models/runway")) {
        printf("Erro: nao consegui carregar a pista\n");
        exit(-1);
    }

    if (!loadModel(TERRAIN_OBJ, TERRAIN_SIZE, 0.0f, false, true, terrainModel, "models/terrain")) {
        printf("Aviso: nao consegui carregar o terreno\n");
    }
}

void deleteModel(Model& m)
{
    for (size_t i = 0; i < m.parts.size(); i++) {
        glDeleteBuffers(1, &m.parts[i].vbo);
    }
}

void cleanupDataFromGPU()
{
    deleteModel(aircraftModel);
    deleteModel(runwayModel);
    deleteModel(terrainModel);

    for (std::map<std::string, GLuint>::iterator it = textureCache.begin();
         it != textureCache.end(); ++it)
        if (it->second != 0) glDeleteTextures(1, &it->second);

    glDeleteVertexArrays(1, &VertexArrayID);
    glDeleteProgram(programID);
}

// ------------------------------------------------------------
// CALLBACKS
// ------------------------------------------------------------
void keyboard_callback(GLFWwindow* w, int key, int scancode, int action, int mods)
{
    if (action != GLFW_PRESS) return;

    if (key == GLFW_KEY_SPACE) {
        if (state == FINISHED) resetSimulation();
        running = !running;
        if (running && state == PARKED) state = ROLLING;
    }
    if (key == GLFW_KEY_R) resetSimulation();
    if (key == GLFW_KEY_C) {
        chaseCamera = !chaseCamera;
        if (!chaseCamera) camTarget = planePos;
    }
}

void mouse_button_callback(GLFWwindow* w, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        dragging = (action == GLFW_PRESS);
        glfwGetCursorPos(w, &lastX, &lastY);
    }
}

void cursor_callback(GLFWwindow* w, double x, double y)
{
    if (!dragging) { lastX = x; lastY = y; return; }
    camYaw   += (float)(x - lastX) * 0.3f;
    camPitch += (float)(y - lastY) * 0.3f;
    camPitch = glm::clamp(camPitch, -5.0f, 89.0f);
    lastX = x; lastY = y;
}

void scroll_callback(GLFWwindow* w, double xoff, double yoff)
{
    camDist *= (1.0f - 0.1f * (float)yoff);
    camDist = glm::clamp(camDist, 5.0f, 800.0f);
}

void processContinuousInput(float dt)
{
    if (chaseCamera) return;
    float v = 40.0f * dt;
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)     camTarget.x += v;
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)      camTarget.x -= v;
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)      camTarget.z += v;
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)        camTarget.z -= v;
    if (glfwGetKey(window, GLFW_KEY_KP_ADD) == GLFW_PRESS)   camTarget.y += v;
    if (glfwGetKey(window, GLFW_KEY_KP_SUBTRACT) == GLFW_PRESS) camTarget.y -= v;
}

// ------------------------------------------------------------
// DESENHO
// ------------------------------------------------------------
glm::mat4 Projection, View;
glm::vec3 camPos;

void setCamera(void)
{
    Projection = glm::perspective(glm::radians(45.0f),
                                  (float)WindowWidth / (float)WindowHeight,
                                  0.1f, 5000.0f);

    glm::vec3 target = chaseCamera ? planePos + glm::vec3(0, 1.5f, 0) : camTarget;
    float yaw = glm::radians(camYaw), pitch = glm::radians(camPitch);
    camPos = target + camDist * glm::vec3(cosf(pitch) * cosf(yaw),
                                          sinf(pitch),
                                          cosf(pitch) * sinf(yaw));
    View = glm::lookAt(camPos, target, glm::vec3(0, 1, 0));
}

void drawModel(const Model& m, const glm::mat4& ModelMat)
{
    if (m.parts.empty()) return;

    glm::mat4 MVP = Projection * View * ModelMat;
    glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);
    glUniformMatrix4fv(ModelID, 1, GL_FALSE, &ModelMat[0][0]);

    glm::mat3 NormalMat = glm::mat3(glm::transpose(glm::inverse(ModelMat)));
    glUniformMatrix3fv(NormalID, 1, GL_FALSE, &NormalMat[0][0]);

    for (size_t i = 0; i < m.parts.size(); i++) {
        const SubMesh& p = m.parts[i];

        glUniform1i(UseTexID, p.tex != 0 ? 1 : 0);
        glUniform3f(ColorID, p.kd.r, p.kd.g, p.kd.b);
        if (p.tex != 0) {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, p.tex);
        }

        glBindBuffer(GL_ARRAY_BUFFER, p.vbo);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
        glDrawArrays(GL_TRIANGLES, 0, p.count);
    }
}

void draw(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glUseProgram(programID);
    glBindVertexArray(VertexArrayID);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    setCamera();
    glUniform1i(TexID, 0);

    glm::vec3 lightPos = planePos + glm::vec3(-30.0f, 80.0f, 40.0f);
    glUniform3f(LightPosID, lightPos.x, lightPos.y, lightPos.z);
    glUniform3f(ViewPosID, camPos.x, camPos.y, camPos.z);

    glm::mat4 I(1.0f);
    
    // 1. Desenhar o Terreno
    drawModel(terrainModel, I);

    // 2. Desenhar a Pista com os offsets aplicados
    glm::mat4 runwayMatrix = glm::translate(I, glm::vec3(0.0f, RUNWAY_OFFSET_Y, RUNWAY_OFFSET_Z));
    drawModel(runwayModel, runwayMatrix);

    // 3. Desenhar o Avião 
    glm::mat4 Model = glm::translate(I, planePos) 
                    * glm::rotate(I, glm::radians(planePitch), glm::vec3(0, 0, 1));
    drawModel(aircraftModel, Model);

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(2);
}

// ------------------------------------------------------------
// MAIN
// ------------------------------------------------------------
int main()
{
    if (!glfwInit()) return -1;

    glfwWindowHint(GLFW_SAMPLES, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    window = glfwCreateWindow(WindowWidth, WindowHeight, "Takeoff Simulator", NULL, NULL);
    if (window == NULL) { glfwTerminate(); return -1; }

    glfwMakeContextCurrent(window);

    glewExperimental = true;
    if (glewInit() != GLEW_OK) { glfwTerminate(); return -1; }

    glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
    glfwSetKeyCallback(window, keyboard_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetCursorPosCallback(window, cursor_callback);
    glfwSetScrollCallback(window, scroll_callback);

    glClearColor(0.53f, 0.74f, 0.92f, 0.0f);   // ceu
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    transferDataToGPUMemory();

    printf("Controlos:\n"
           "  ESPACO  iniciar/pausar descolagem\n"
           "  R       reiniciar\n"
           "  C       camara seguir aviao / livre\n"
           "  Rato    arrastar (botao esq.) para rodar, scroll para zoom\n"
           "  Setas, +/-: mover camara (modo livre)\n");

    double lastTime = glfwGetTime();
    double lastTitle = 0.0;

    do {
        double now = glfwGetTime();
        float dt = (float)(now - lastTime);
        if (dt > 0.1f) dt = 0.1f;
        lastTime = now;

        processContinuousInput(dt);
        updateSimulation(dt); 
        draw();

        if (now - lastTitle > 0.2) {
            char title[160];
            snprintf(title, sizeof(title),
                     "Takeoff | %s | vel: %.0f km/h | alt: %.1f m | pitch: %.1f",
                     stateName(state), planeSpeed * 3.6f, planePos.y - RUNWAY_OFFSET_Y, planePitch);
            glfwSetWindowTitle(window, title);
            lastTitle = now;
        }

        glfwSwapBuffers(window);
        glfwPollEvents();

    } while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
             glfwWindowShouldClose(window) == 0);

    cleanupDataFromGPU();
    glfwTerminate();
    return 0;
}